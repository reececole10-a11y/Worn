import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import {
  Home as HomeIcon,
  Search,
  Star,
  Flame,
  X,
  Check,
  ChevronLeft,
  ChevronRight,
  Award,
  Plus,
  User as UserIcon,
  Calendar as CalendarIcon,
  BarChart3,
  Shirt as ShirtIcon,
  Camera,
  Image as ImageIcon,
  Trash2,
  Pencil,
  Sparkles,
  Sun,
  Moon,
  Loader2,
  RotateCcw,
  ArrowUpRight,
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

/* ══════════════════════════ Tokens ══════════════════════════
   Every colour resolves through a CSS variable, so flipping the
   theme class on the root swaps the whole app at once.           */
const C = {
  bg: "var(--w-bg)",
  card: "var(--w-card)",
  accent: "var(--w-accent)",
  accentSoft: "var(--w-accent-soft)",
  success: "var(--w-success)",
  warning: "var(--w-warning)",
  danger: "var(--w-danger)",
  text: "var(--w-text)",
  sub: "var(--w-sub)",
  faint: "var(--w-faint)",
  line: "var(--w-line)",
  wash: "var(--w-wash)",
  veil: "var(--w-veil)",
  navVeil: "var(--w-nav-veil)",
  onAccent: "var(--w-on-accent)",
  invText: "var(--w-inv-text)",
  invBg: "var(--w-inv-bg)",
};

const THEME_KEY = "worn:theme";

const CATEGORIES = ["Hoodie", "Sweater", "Shirt", "Jacket", "Pants", "Shorts", "Shoes", "Hat", "Accessory"];
const TOP_CATS = ["Hoodie", "Sweater", "Shirt"];
const BOTTOM_CATS = ["Pants", "Shorts"];
const SHOE_CATS = ["Shoes"];
const ACCESSORY_CATS = ["Jacket", "Hat", "Accessory"];
const SEASONS = ["All-season", "Spring", "Summer", "Fall", "Winter"];
const CONDITIONS = ["Excellent", "Good", "Fair", "Worn"];

const DATA_KEY = "worn:data:v1";
const PHOTO_BUCKETS = 8;
const photoKey = (b) => `worn:photos:${b}`;

/* ══════════════════════════ Motion ══════════════════════════ */
const MOTION_CSS = `
:root, .w-light {
  --w-bg: #F8F8F6;
  --w-card: #FFFFFF;
  --w-accent: #3B82F6;
  --w-accent-soft: #F0F5FF;
  --w-success: #22C55E;
  --w-warning: #F59E0B;
  --w-danger: #EF4444;
  --w-text: #111827;
  --w-sub: #6B7280;
  --w-faint: #9CA3AF;
  --w-line: #ECECE8;
  --w-wash: #F3F3F0;
  --w-veil: rgba(248,248,246,.86);
  --w-nav-veil: rgba(255,255,255,.92);
  --w-on-accent: #FFFFFF;
  --w-inv-bg: #111827;
  --w-inv-text: #FFFFFF;
  --w-heat-0: #F0F0EC;
  --w-heat-1: #D6E4FA;
  --w-heat-2: #A9C8F5;
  --w-heat-3: #6EA3EE;
  --w-heat-4: #3B82F6;
  --w-shim-a: #F3F3F0;
  --w-shim-b: #E8E8E4;
  --w-scrim: rgba(17,24,39,.32);
  color-scheme: light;
}

.w-dark {
  --w-bg: #0E0E11;
  --w-card: #17171B;
  --w-accent: #6BA5FB;
  --w-accent-soft: #17253C;
  --w-success: #3DD68C;
  --w-warning: #FBBF24;
  --w-danger: #F87171;
  --w-text: #F2F2F0;
  --w-sub: #A3A3A8;
  --w-faint: #6B6B72;
  --w-line: #27272C;
  --w-wash: #202024;
  --w-veil: rgba(14,14,17,.84);
  --w-nav-veil: rgba(23,23,27,.92);
  --w-on-accent: #0E0E11;
  --w-inv-bg: #F2F2F0;
  --w-inv-text: #0E0E11;
  --w-heat-0: #202024;
  --w-heat-1: #1D3452;
  --w-heat-2: #2C5C96;
  --w-heat-3: #4380CE;
  --w-heat-4: #6BA5FB;
  --w-shim-a: #202024;
  --w-shim-b: #2B2B31;
  --w-scrim: rgba(0,0,0,.55);
  color-scheme: dark;
}

@keyframes wFadeUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: none; } }
@keyframes wFadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes wSheetUp { from { transform: translateY(100%); } to { transform: none; } }
@keyframes wPop { 0% { transform: scale(.7); opacity: 0; } 60% { transform: scale(1.08); } 100% { transform: scale(1); opacity: 1; } }
@keyframes wShimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
@keyframes wSpin { to { transform: rotate(360deg); } }
@keyframes wToast { from { opacity: 0; transform: translate(-50%, 14px); } to { opacity: 1; transform: translate(-50%, 0); } }
@keyframes wRise { from { opacity: 0; transform: translateY(12px) scale(.94); } to { opacity: 1; transform: none; } }

.w-in { animation: wFadeUp .42s cubic-bezier(.22,.9,.3,1) both; }
.w-fade { animation: wFadeIn .3s ease both; }
.w-sheet { animation: wSheetUp .34s cubic-bezier(.22,.9,.3,1) both; }
.w-pop { animation: wPop .32s cubic-bezier(.34,1.4,.5,1) both; }
.w-toast { animation: wToast .28s cubic-bezier(.22,.9,.3,1) both; }
.w-rise { animation: wRise .26s cubic-bezier(.22,.9,.3,1) both; }

.w-press { transition: transform .18s cubic-bezier(.22,.9,.3,1), opacity .18s ease, background-color .18s ease, border-color .18s ease, color .18s ease; }
.w-press:active { transform: scale(.975); }

.w-fab { transition: transform .28s cubic-bezier(.34,1.3,.5,1), background-color .2s ease; }

.w-shimmer {
  background: linear-gradient(90deg, var(--w-shim-a) 25%, var(--w-shim-b) 50%, var(--w-shim-a) 75%);
  background-size: 200% 100%;
  animation: wShimmer 1.4s linear infinite;
}

.w-scroll::-webkit-scrollbar { display: none; }
.w-scroll { scrollbar-width: none; -ms-overflow-style: none; }

input:focus-visible, select:focus-visible, textarea:focus-visible, button:focus-visible {
  outline: 2px solid var(--w-accent);
  outline-offset: 2px;
}

input::placeholder, textarea::placeholder { color: var(--w-faint); }

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
  }
}
`;

/* ══════════════════════════ Dates ══════════════════════════ */
const ymd = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const addDays = (base, n) => {
  const d = new Date(base);
  d.setDate(d.getDate() + n);
  return d;
};
const parseYmd = (s) => new Date(s + "T00:00:00");
const daysBetween = (a, b) => Math.round((parseYmd(a) - parseYmd(b)) / 86400000);
const daysSince = (s) => (s ? Math.max(0, daysBetween(ymd(new Date()), s)) : null);
function lastWornLabel(s) {
  const n = daysSince(s);
  if (n === null) return "Never worn";
  if (n === 0) return "Today";
  if (n === 1) return "Yesterday";
  return `${n} days ago`;
}

/* ══════════════════════════ Storage ══════════════════════════ */
function bucketFor(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return h % PHOTO_BUCKETS;
}

/*
  Two stores, on purpose:

  - localStorage holds the item metadata and theme. Small, synchronous, fine.
  - IndexedDB holds the photos. localStorage caps out around 5 MB across the
    whole origin, and a couple of dozen compressed photos will blow through
    that, so images live in IDB where the budget is hundreds of megabytes.

  Both are wrapped so a failure degrades to "no saved data" rather than a
  frozen screen — Safari private mode throws on write, for instance.
*/

const IDB_NAME = "worn";
const IDB_STORE = "photos";

function openDB() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") return reject(new Error("No IndexedDB"));
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("IndexedDB open failed"));
  });
}

async function idbGet(key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, "readonly");
    const req = tx.objectStore(IDB_STORE).get(key);
    req.onsuccess = () => resolve(req.result ?? null);
    req.onerror = () => reject(req.error);
  });
}

async function idbSet(key, value) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, "readwrite");
    tx.objectStore(IDB_STORE).put(value, key);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

const isPhotoKey = (key) => key.startsWith("worn:photos:");

async function safeGet(key) {
  try {
    if (isPhotoKey(key)) return await idbGet(key);
    if (typeof localStorage === "undefined") return null;
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

async function safeSet(key, value) {
  try {
    if (isPhotoKey(key)) {
      await idbSet(key, value);
      return true;
    }
    if (typeof localStorage === "undefined") return false;
    localStorage.setItem(key, value);
    return true;
  } catch (e) {
    console.error("Storage write failed", key, e);
    return false;
  }
}

/* ══════════════════════════ Images ══════════════════════════ */
function loadImage(src) {
  return new Promise((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = () => rej(new Error("That file isn't a readable image."));
    i.src = src;
  });
}

async function compressImage(file, maxDim = 640, quality = 0.72) {
  const dataUrl = await new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(new Error("Could not read that file."));
    r.readAsDataURL(file);
  });
  const img = await loadImage(dataUrl);
  const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(img, 0, 0, w, h);
  return canvas.toDataURL("image/jpeg", quality);
}

/* ══════════════════════════ Colour naming ══════════════════════════
   Runs entirely on-device off a canvas — no network, always works.   */
const NAMED_COLORS = [
  ["Black", 24, 24, 26], ["Charcoal", 62, 62, 66], ["Gray", 128, 128, 132],
  ["Light gray", 190, 190, 192], ["White", 246, 246, 244], ["Cream", 240, 232, 214],
  ["Beige", 214, 196, 168], ["Tan", 186, 154, 112], ["Brown", 124, 84, 52],
  ["Burgundy", 108, 32, 48], ["Red", 200, 44, 44], ["Orange", 230, 122, 38],
  ["Yellow", 232, 200, 62], ["Olive", 116, 122, 62], ["Green", 58, 148, 78],
  ["Mint", 158, 214, 184], ["Teal", 42, 134, 138], ["Light blue", 148, 190, 232],
  ["Blue", 48, 104, 198], ["Navy", 30, 44, 92], ["Purple", 122, 66, 176],
  ["Pink", 232, 150, 178], ["Gold", 198, 162, 62], ["Silver", 200, 202, 206],
];

function nearestColorName(r, g, b) {
  let best = NAMED_COLORS[0];
  let bestD = Infinity;
  for (const c of NAMED_COLORS) {
    const d = (r - c[1]) ** 2 * 0.3 + (g - c[2]) ** 2 * 0.59 + (b - c[3]) ** 2 * 0.11;
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  return best[0];
}

async function detectColor(dataUrl) {
  try {
    const img = await loadImage(dataUrl);
    const S = 48;
    const canvas = document.createElement("canvas");
    canvas.width = S;
    canvas.height = S;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0, S, S);
    const { data } = ctx.getImageData(0, 0, S, S);

    // Weight the centre; garments sit in the middle, backgrounds at the edges.
    const buckets = new Map();
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const i = (y * S + x) * 4;
        const dx = (x - S / 2) / (S / 2);
        const dy = (y - S / 2) / (S / 2);
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > 0.92) continue;
        const weight = 1 - dist * 0.75;
        const r = data[i], g = data[i + 1], b = data[i + 2];
        const key = `${r >> 4}-${g >> 4}-${b >> 4}`;
        const prev = buckets.get(key) || { r: 0, g: 0, b: 0, w: 0 };
        buckets.set(key, {
          r: prev.r + r * weight,
          g: prev.g + g * weight,
          b: prev.b + b * weight,
          w: prev.w + weight,
        });
      }
    }
    let top = null;
    for (const v of buckets.values()) if (!top || v.w > top.w) top = v;
    if (!top) return null;
    const r = Math.round(top.r / top.w);
    const g = Math.round(top.g / top.w);
    const b = Math.round(top.b / top.w);
    return { name: nearestColorName(r, g, b), hex: `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("")}` };
  } catch {
    return null;
  }
}

/* ══════════════════════════ Clothing scanner ══════════════════════════
   Tries the free Hugging Face inference endpoint first. That endpoint is
   frequently unavailable from a browser (CORS, cold starts, tokenless
   throttling), so it falls back to Claude vision, then to colour-only.  */

const IMAGENET_MAP = [
  [/sweatshirt|hoodie/i, "Hoodie"],
  [/cardigan|wool|knit/i, "Sweater"],
  [/jersey|t-shirt|tee shirt|polo|shirt|bib/i, "Shirt"],
  [/trench coat|fur coat|lab coat|coat|windbreaker|blazer|suit|vest|poncho|kimono|abaya|gown/i, "Jacket"],
  [/jean|denim|trouser|pajama|sweatpant|legging|slack/i, "Pants"],
  [/short|swimming trunks|miniskirt|skirt/i, "Shorts"],
  [/running shoe|sneaker|loafer|sandal|clog|boot|shoe|oxford/i, "Shoes"],
  [/sombrero|cowboy hat|bonnet|helmet|beanie|cap|hat|bearskin/i, "Hat"],
  [/necklace|sunglass|backpack|purse|wallet|mitten|sock|tie|bow tie|scarf|belt|watch|glove|bag/i, "Accessory"],
];

function mapLabelToCategory(label) {
  for (const [re, cat] of IMAGENET_MAP) if (re.test(label)) return cat;
  return null;
}

const SEASON_HINT = {
  Hoodie: "Fall", Sweater: "Winter", Jacket: "Winter",
  Shirt: "All-season", Pants: "All-season", Shorts: "Summer",
  Shoes: "All-season", Hat: "All-season", Accessory: "All-season",
};

function dataUrlToBlob(dataUrl) {
  const [meta, b64] = dataUrl.split(",");
  const mime = meta.match(/:(.*?);/)[1];
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}

async function scanWithHuggingFace(dataUrl) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const res = await fetch("https://api-inference.huggingface.co/models/microsoft/resnet-50", {
      method: "POST",
      headers: { "Content-Type": "image/jpeg" },
      body: dataUrlToBlob(dataUrl),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`HF ${res.status}`);
    const json = await res.json();
    if (!Array.isArray(json)) throw new Error("Unexpected response");

    for (const row of json) {
      const cat = mapLabelToCategory(row.label || "");
      if (cat) {
        return {
          category: cat,
          rawLabel: (row.label || "").split(",")[0],
          confidence: row.score,
          source: "Hugging Face",
        };
      }
    }
    throw new Error("No clothing recognised");
  } finally {
    clearTimeout(timeout);
  }
}

async function scanWithClaude(dataUrl) {
  const base64 = dataUrl.split(",")[1];
  // Routed through our own serverless function so the API key never reaches
  // the browser. See api/scan.js — without it deployed, this throws and the
  // scanner falls back to Hugging Face.
  const res = await fetch("/api/scan", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      tools: [{ type: "web_search_20250305", name: "web_search" }],
      messages: [
        {
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: "image/jpeg", data: base64 } },
            {
              type: "text",
              text:
                `Identify this garment.\n\n` +
                `For price: if a price tag is legible in the photo, use that figure. ` +
                `Otherwise, if you can make out the brand and model, search the web for its current retail price. ` +
                `If you can only guess the category, give a typical retail price for that kind of item. ` +
                `Set priceBasis to whichever applies: "tag", "retail", "typical", or "" if you cannot tell.\n\n` +
                `Respond with ONLY a JSON object, no markdown, no preamble:\n` +
                `{"category": one of ${JSON.stringify(CATEGORIES)}, ` +
                `"color": short colour name, ` +
                `"brand": visible brand name or empty string, ` +
                `"material": best guess or empty string, ` +
                `"name": a short 2-4 word item name, ` +
                `"season": one of ${JSON.stringify(SEASONS)}, ` +
                `"price": number in USD or null, ` +
                `"priceBasis": "tag" | "retail" | "typical" | "", ` +
                `"confidence": 0 to 1}\n` +
                `If it is not clothing, set category to "" and confidence to 0.`,
            },
          ],
        },
      ],
    }),
  });
  if (!res.ok) throw new Error(`Scan API ${res.status}`);
  const data = await res.json();
  const text = (data.content || [])
    .map((b) => (b.type === "text" ? b.text : ""))
    .join("")
    .replace(/```json|```/g, "")
    .trim();

  // Web search results can wrap the JSON in commentary — take the object.
  const match = text.match(/\{[\s\S]*\}/);
  const parsed = JSON.parse(match ? match[0] : text);
  if (!parsed.category) throw new Error("No clothing recognised");
  return { ...parsed, source: "Claude" };
}

async function scanClothing(dataUrl) {
  const color = await detectColor(dataUrl);
  const errors = [];

  // Claude first — it's the only path that can read a price tag or look up
  // retail. ResNet is the fallback and returns category only.
  for (const attempt of [scanWithClaude, scanWithHuggingFace]) {
    try {
      const result = await attempt(dataUrl);
      const price = Number(result.price);
      return {
        ok: true,
        category: result.category,
        color: result.color || color?.name || "",
        brand: result.brand || "",
        material: result.material || "",
        name: result.name || result.rawLabel || "",
        season: result.season || SEASON_HINT[result.category] || "All-season",
        price: Number.isFinite(price) && price > 0 ? Math.round(price) : null,
        priceBasis: result.priceBasis || "",
        confidence: result.confidence ?? null,
        source: result.source,
        swatch: color?.hex,
      };
    } catch (e) {
      errors.push(e.message);
    }
  }

  // Both models unreachable — the on-device colour read still stands.
  if (color) {
    return {
      ok: true,
      partial: true,
      category: "",
      color: color.name,
      brand: "",
      material: "",
      name: "",
      season: "",
      price: null,
      priceBasis: "",
      confidence: null,
      source: "on-device colour",
      swatch: color.hex,
    };
  }
  return { ok: false, error: errors[errors.length - 1] || "Scan failed" };
}

/* ══════════════════════════ Sample data ══════════════════════════ */
function sampleCloset() {
  // Always start empty — no demo data
  return { items: [], outfitLog: {} };
}

/* ══════════════════════════ Stats helpers ══════════════════════════ */
function computeStreak(log) {
  let streak = 0;
  let cursor = new Date();
  if (!log[ymd(cursor)]) cursor = addDays(cursor, -1);
  while (log[ymd(cursor)]) {
    streak++;
    cursor = addDays(cursor, -1);
  }
  return streak;
}
function longestStreak(log) {
  const keys = Object.keys(log).sort();
  let best = 0, run = 0, prev = null;
  for (const k of keys) {
    run = prev && daysBetween(k, prev) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    prev = k;
  }
  return best;
}

/* ══════════════════════════ Atoms ══════════════════════════ */
function Panel({ children, style, className = "", onClick, delay = 0 }) {
  return (
    <div
      onClick={onClick}
      className={`rounded-2xl w-in ${onClick ? "w-press cursor-pointer" : ""} ${className}`}
      style={{
        backgroundColor: C.card,
        border: `1px solid ${C.line}`,
        animationDelay: `${delay}ms`,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function Eyebrow({ children, className = "" }) {
  return (
    <p
      className={`text-[11px] font-medium uppercase mb-2.5 ${className}`}
      style={{ color: C.faint, letterSpacing: "0.09em" }}
    >
      {children}
    </p>
  );
}

function Chip({ active, children, onClick }) {
  return (
    <button
      onClick={onClick}
      className="px-3.5 py-1.5 rounded-full text-[13px] whitespace-nowrap w-press"
      style={{
        backgroundColor: active ? C.invBg : "transparent",
        color: active ? C.invText : C.sub,
        border: `1px solid ${active ? C.text : C.line}`,
        fontWeight: active ? 500 : 400,
      }}
    >
      {children}
    </button>
  );
}

function Thumb({ item, photo, size = 56, radius = 12 }) {
  if (photo) {
    return (
      <img
        src={photo}
        alt={item?.name || ""}
        className="object-cover shrink-0"
        style={{ width: size, height: size, borderRadius: radius, backgroundColor: C.wash }}
      />
    );
  }
  return (
    <div
      className="flex items-center justify-center shrink-0"
      style={{ width: size, height: size, borderRadius: radius, backgroundColor: C.wash }}
    >
      <ShirtIcon size={Math.round(size * 0.4)} color={C.faint} strokeWidth={1.4} />
    </div>
  );
}

function PrimaryButton({ children, onClick, disabled, tone = "accent" }) {
  const bg = tone === "accent" ? C.accent : C.invBg;
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full rounded-2xl py-3.5 text-[15px] font-medium disabled:opacity-30 w-press"
      style={{ backgroundColor: bg, color: tone === "accent" ? C.onAccent : C.invText }}
    >
      {children}
    </button>
  );
}

function QuietButton({ children, onClick, icon: Icon }) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center justify-center gap-2 rounded-2xl py-3 text-[14px] w-press"
      style={{ backgroundColor: "transparent", border: `1px solid ${C.line}`, color: C.text }}
    >
      {Icon && <Icon size={15} />}
      {children}
    </button>
  );
}

/* ══════════════════════════ Photo picker + scanner ══════════════════════════ */
function PhotoPicker({ value, onChange, onScanResult }) {
  const libraryRef = useRef(null);
  const cameraRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scanNote, setScanNote] = useState(null);
  const [error, setError] = useState("");

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setError("");
    setScanNote(null);
    setBusy(true);
    try {
      const compressed = await compressImage(file);
      onChange(compressed);
    } catch (err) {
      setError(err.message || "Couldn't process that image.");
    } finally {
      setBusy(false);
    }
  };

  const runScan = async () => {
    if (!value || scanning) return;
    setScanning(true);
    setError("");
    setScanNote(null);
    const result = await scanClothing(value);
    setScanning(false);
    if (!result.ok) {
      setError("Couldn't identify this one — fill it in below and it'll save the same way.");
      return;
    }
    onScanResult(result);
    setScanNote(
      result.partial
        ? { text: `Colour read on-device: ${result.color}. The garment models are offline, so pick a category yourself.`, tone: "warn" }
        : {
            text: `${result.category}${result.color ? ` · ${result.color}` : ""}${
              result.price ? ` · ~$${result.price}` : ""
            }${result.confidence ? ` · ${Math.round(result.confidence * 100)}% sure` : ""}`,
            tone: "ok",
            source: result.source,
          }
    );
  };

  return (
    <div>
      <input ref={libraryRef} type="file" accept="image/*" onChange={handleFile} style={{ display: "none" }} />
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" onChange={handleFile} style={{ display: "none" }} />

      <div
        className="relative rounded-2xl overflow-hidden flex items-center justify-center"
        style={{
          height: 190,
          backgroundColor: value ? C.wash : C.card,
          border: `1px ${value ? "solid" : "dashed"} ${value ? C.line : "#DCDCD6"}`,
        }}
      >
        {value ? (
          <>
            <img src={value} alt="Item" className="w-full h-full object-cover w-fade" />
            {scanning && (
              <div
                className="absolute inset-0 flex flex-col items-center justify-center gap-2 w-fade"
                style={{ backgroundColor: "rgba(255,255,255,0.86)", backdropFilter: "blur(2px)" }}
              >
                <Loader2 size={20} color={C.accent} style={{ animation: "wSpin 1s linear infinite" }} />
                <p className="text-[12px]" style={{ color: C.sub }}>
                  Reading the photo
                </p>
              </div>
            )}
            <div className="absolute bottom-2.5 right-2.5 flex gap-2">
              <button
                onClick={() => libraryRef.current?.click()}
                className="rounded-full px-3 py-1.5 text-[11px] font-medium w-press"
                style={{ backgroundColor: "rgba(17,24,39,0.7)", color: "#fff", backdropFilter: "blur(4px)" }}
              >
                Replace
              </button>
              <button
                onClick={() => {
                  onChange(null);
                  setScanNote(null);
                }}
                className="rounded-full px-3 py-1.5 text-[11px] font-medium w-press"
                style={{ backgroundColor: "rgba(17,24,39,0.7)", color: "#fff", backdropFilter: "blur(4px)" }}
              >
                Remove
              </button>
            </div>
          </>
        ) : busy ? (
          <div className="flex flex-col items-center gap-2.5">
            <Loader2 size={20} color={C.accent} style={{ animation: "wSpin 1s linear infinite" }} />
            <p className="text-[12px]" style={{ color: C.sub }}>
              Processing photo
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3.5 px-4">
            <p className="text-[13px]" style={{ color: C.sub }}>
              Add a photo
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => libraryRef.current?.click()}
                className="flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[12px] w-press"
                style={{ border: `1px solid ${C.line}`, color: C.text, backgroundColor: C.card }}
              >
                <ImageIcon size={14} color={C.accent} />
                Choose photo
              </button>
              <button
                onClick={() => cameraRef.current?.click()}
                className="flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[12px] w-press"
                style={{ border: `1px solid ${C.line}`, color: C.text, backgroundColor: C.card }}
              >
                <Camera size={14} color={C.accent} />
                Take photo
              </button>
            </div>
          </div>
        )}
      </div>

      {value && (
        <button
          onClick={runScan}
          disabled={scanning}
          className="w-full mt-2.5 flex items-center justify-center gap-2 rounded-2xl py-2.5 text-[13px] font-medium disabled:opacity-50 w-press"
          style={{ backgroundColor: C.accentSoft, color: C.accent, border: `1px solid #DCE7FB` }}
        >
          <Sparkles size={14} />
          {scanning ? "Scanning" : "Identify this item"}
        </button>
      )}

      {scanNote && (
        <div className="flex items-start gap-2 mt-2.5 px-1 w-in">
          <Check size={13} color={scanNote.tone === "ok" ? C.success : C.warning} className="mt-[3px] shrink-0" />
          <p className="text-[12px] leading-snug" style={{ color: C.sub }}>
            {scanNote.text}
            {scanNote.source && (
              <span style={{ color: C.faint }}> · via {scanNote.source}</span>
            )}
          </p>
        </div>
      )}

      {error && (
        <p className="text-[12px] mt-2.5 px-1 leading-snug w-in" style={{ color: C.warning }}>
          {error}
        </p>
      )}
    </div>
  );
}

/* ══════════════════════════ Home ══════════════════════════ */
function HomeScreen({ items, photos, outfitLog, streak, onLogOutfit, onOpenItem, onGoCloset }) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const todayKey = ymd(new Date());
  const todayEntry = outfitLog[todayKey];
  const todayItems = (todayEntry?.items || []).map((id) => items.find((i) => i.id === id)).filter(Boolean);

  const worn = items.filter((i) => i.wears > 0);
  const mostWorn = worn.length ? [...worn].sort((a, b) => b.wears - a.wears)[0] : null;
  const neglected = items.length
    ? [...items].sort((a, b) => (daysSince(b.lastWorn) ?? 9999) - (daysSince(a.lastWorn) ?? 9999))[0]
    : null;

  const suggestion = useMemo(() => {
    const stale = items
      .filter((i) => {
        const n = daysSince(i.lastWorn);
        return n === null || n > 30;
      })
      .sort((a, b) => (daysSince(b.lastWorn) ?? 9999) - (daysSince(a.lastWorn) ?? 9999))[0];
    if (!stale) return null;
    const n = daysSince(stale.lastWorn);
    return n === null
      ? `Your ${stale.name.toLowerCase()} has never been worn.`
      : `Your ${stale.name.toLowerCase()} has sat untouched for ${n} days.`;
  }, [items]);

  return (
    <div className="px-5 pt-3 pb-8">
      <div className="w-in" style={{ animationDelay: "0ms" }}>
        <p className="text-[13px]" style={{ color: C.faint }}>
          {greeting}
        </p>
        <h1 className="text-[28px] font-medium mt-1 tracking-tight leading-none" style={{ color: C.text }}>
          Today
        </h1>
      </div>

      <div className="mt-6">
        {todayItems.length > 0 ? (
          <Panel style={{ padding: 18 }} delay={60}>
            <div className="flex gap-2.5 mb-3.5 overflow-x-auto w-scroll">
              {todayItems.map((it, i) => (
                <button key={it.id} onClick={() => onOpenItem(it)} className="w-press w-pop" style={{ animationDelay: `${100 + i * 50}ms` }}>
                  <Thumb item={it} photo={photos[it.id]} size={64} radius={14} />
                </button>
              ))}
            </div>
            <p className="text-[13px] leading-relaxed" style={{ color: C.sub }}>
              {todayItems.map((i) => i.name).join(" · ")}
            </p>
            {todayEntry?.note && (
              <p className="text-[13px] mt-2" style={{ color: C.faint }}>
                {todayEntry.note}
              </p>
            )}
            <button onClick={onLogOutfit} className="mt-3.5 text-[13px] font-medium w-press" style={{ color: C.accent }}>
              Edit
            </button>
          </Panel>
        ) : items.length === 0 ? (
          <Panel style={{ padding: 22 }} delay={60}>
            <p className="text-[15px] font-medium" style={{ color: C.text }}>
              Your closet is empty
            </p>
            <p className="text-[13px] mt-1.5 mb-5 leading-relaxed" style={{ color: C.sub }}>
              Add a few pieces and you can start tracking what you actually wear.
            </p>
            <PrimaryButton onClick={onGoCloset}>Add your first item</PrimaryButton>
          </Panel>
        ) : (
          <button
            onClick={onLogOutfit}
            className="w-full flex items-center justify-center gap-2 rounded-2xl py-4 font-medium text-white text-[15px] w-press w-in"
            style={{ backgroundColor: C.accent, animationDelay: "60ms" }}
          >
            <Plus size={18} strokeWidth={2.2} />
            Log outfit
          </button>
        )}
      </div>

      <div className="mt-3">
        <Panel style={{ padding: 18 }} className="flex items-center justify-between" delay={120}>
          <div className="flex items-center gap-3">
            <Flame size={19} color={streak > 0 ? C.warning : C.faint} fill={streak > 0 ? C.warning : "none"} strokeWidth={1.7} />
            <span className="text-[14px]" style={{ color: C.text }}>
              Streak
            </span>
          </div>
          <span className="text-[14px] font-medium" style={{ color: streak > 0 ? C.text : C.faint }}>
            {streak === 0 ? "None yet" : `${streak} day${streak === 1 ? "" : "s"}`}
          </span>
        </Panel>
      </div>

      {suggestion && (
        <div className="mt-3">
          <Panel style={{ padding: 18 }} delay={180}>
            <Eyebrow>Nudge</Eyebrow>
            <p className="text-[14px] leading-relaxed" style={{ color: C.text }}>
              {suggestion}
            </p>
          </Panel>
        </div>
      )}

      {items.length > 0 && (
        <div className="grid grid-cols-2 gap-3 mt-3">
          <Panel style={{ padding: 16 }} delay={240} onClick={() => mostWorn && onOpenItem(mostWorn)}>
            <Eyebrow>Most worn</Eyebrow>
            {mostWorn ? (
              <>
                <Thumb item={mostWorn} photo={photos[mostWorn.id]} size={44} radius={11} />
                <p className="text-[13px] font-medium mt-2.5 leading-snug" style={{ color: C.text }}>
                  {mostWorn.name}
                </p>
                <p className="text-[12px] mt-1" style={{ color: C.faint }}>
                  {mostWorn.wears} wears
                </p>
              </>
            ) : (
              <p className="text-[12px]" style={{ color: C.faint }}>
                Nothing logged yet
              </p>
            )}
          </Panel>
          <Panel style={{ padding: 16 }} delay={290} onClick={() => neglected && onOpenItem(neglected)}>
            <Eyebrow>Least worn</Eyebrow>
            {neglected && (
              <>
                <Thumb item={neglected} photo={photos[neglected.id]} size={44} radius={11} />
                <p className="text-[13px] font-medium mt-2.5 leading-snug" style={{ color: C.text }}>
                  {neglected.name}
                </p>
                <p className="text-[12px] mt-1" style={{ color: C.faint }}>
                  {lastWornLabel(neglected.lastWorn)}
                </p>
              </>
            )}
          </Panel>
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════ Closet ══════════════════════════ */
function ClosetScreen({ items, photos, onAddItem, onOpenItem }) {
  const [filter, setFilter] = useState("All");
  const [query, setQuery] = useState("");

  const filtered = items.filter((i) => {
    const matchesCat = filter === "All" || i.category === filter;
    const q = query.trim().toLowerCase();
    return matchesCat && (!q || `${i.name} ${i.brand} ${i.color} ${i.category}`.toLowerCase().includes(q));
  });
  const usedCats = CATEGORIES.filter((c) => items.some((i) => i.category === c));

  return (
    <div className="px-5 pt-3 pb-8">
      <div className="flex items-end justify-between w-in">
        <h1 className="text-[28px] font-medium tracking-tight leading-none" style={{ color: C.text }}>
          Closet
        </h1>
        <button
          onClick={onAddItem}
          className="flex items-center gap-1.5 text-[13px] font-medium w-press"
          style={{ color: C.accent }}
        >
          <Plus size={15} strokeWidth={2.2} />
          Add
        </button>
      </div>

      {items.length === 0 ? (
        <Panel style={{ padding: 24 }} className="mt-6 text-center" delay={60}>
          <p className="text-[15px] font-medium" style={{ color: C.text }}>
            Nothing here yet
          </p>
          <p className="text-[13px] mt-1.5 mb-5 leading-relaxed" style={{ color: C.sub }}>
            Photograph a piece to add it.
          </p>
          <PrimaryButton onClick={onAddItem}>Add an item</PrimaryButton>
        </Panel>
      ) : (
        <>
          <div
            className="flex items-center gap-2.5 rounded-xl px-3.5 py-2.5 mt-5 w-in"
            style={{ backgroundColor: C.card, border: `1px solid ${C.line}`, animationDelay: "60ms" }}
          >
            <Search size={15} color={C.faint} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search"
              className="text-[14px] bg-transparent outline-none flex-1"
              style={{ color: C.text }}
            />
            {query && (
              <button onClick={() => setQuery("")} className="w-press">
                <X size={14} color={C.faint} />
              </button>
            )}
          </div>

          <div className="flex gap-2 overflow-x-auto w-scroll py-3 -mx-5 px-5 w-in" style={{ animationDelay: "100ms" }}>
            <Chip active={filter === "All"} onClick={() => setFilter("All")}>
              All {items.length}
            </Chip>
            {usedCats.map((c) => (
              <Chip key={c} active={filter === c} onClick={() => setFilter(c)}>
                {c}s
              </Chip>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3 mt-1">
            {filtered.map((item, idx) => (
              <Panel key={item.id} style={{ padding: 10 }} delay={Math.min(idx * 35, 320)} onClick={() => onOpenItem(item)}>
                <div className="relative">
                  {photos[item.id] ? (
                    <img src={photos[item.id]} alt={item.name} className="w-full object-cover rounded-xl" style={{ height: 118 }} />
                  ) : (
                    <div className="flex items-center justify-center rounded-xl" style={{ height: 118, backgroundColor: C.wash }}>
                      <ShirtIcon size={28} color={C.faint} strokeWidth={1.3} />
                    </div>
                  )}
                  {item.favorite && <Star size={14} className="absolute top-2 right-2" color="#fff" fill={C.warning} />}
                </div>
                <p className="text-[13px] font-medium mt-2.5 leading-snug" style={{ color: C.text }}>
                  {item.name}
                </p>
                <p className="text-[12px] mt-0.5" style={{ color: C.faint }}>
                  {item.brand}
                </p>
                <p className="text-[12px] mt-1.5" style={{ color: C.sub }}>
                  {item.wears} {item.wears === 1 ? "wear" : "wears"}
                </p>
              </Panel>
            ))}
            {filtered.length === 0 && (
              <div className="col-span-2 text-center py-14 w-fade">
                <p className="text-[13px]" style={{ color: C.faint }}>
                  Nothing matches that.
                </p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

/* ══════════════════════════ Calendar ══════════════════════════ */
function CalendarScreen({ items, photos, outfitLog, onOpenItem, onLogFor }) {
  const [monthOffset, setMonthOffset] = useState(0);
  const [selected, setSelected] = useState(ymd(new Date()));

  const base = new Date();
  base.setDate(1);
  base.setMonth(base.getMonth() + monthOffset);
  const year = base.getFullYear();
  const month = base.getMonth();
  const firstDow = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [...Array(firstDow).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];

  const todayKey = ymd(new Date());
  const entry = outfitLog[selected];
  const selectedItems = (entry?.items || []).map((id) => items.find((i) => i.id === id)).filter(Boolean);
  const isFuture = parseYmd(selected) > new Date();

  return (
    <div className="px-5 pt-3 pb-8">
      <h1 className="text-[28px] font-medium tracking-tight leading-none w-in" style={{ color: C.text }}>
        Calendar
      </h1>

      <Panel style={{ padding: 16 }} className="mt-6" delay={60}>
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => setMonthOffset((m) => m - 1)} className="p-1 w-press">
            <ChevronLeft size={17} color={C.faint} />
          </button>
          <p className="text-[14px] font-medium" style={{ color: C.text }}>
            {base.toLocaleString("default", { month: "long" })} {year}
          </p>
          <button onClick={() => setMonthOffset((m) => m + 1)} className="p-1 w-press">
            <ChevronRight size={17} color={C.faint} />
          </button>
        </div>
        <div className="grid grid-cols-7 gap-1 mb-2">
          {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
            <div key={i} className="text-center text-[10px]" style={{ color: C.faint }}>
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1" key={monthOffset}>
          {cells.map((d, idx) => {
            if (!d) return <div key={idx} />;
            const key = ymd(new Date(year, month, d));
            const dayEntry = outfitLog[key];
            const firstPhoto = dayEntry?.items?.map((id) => photos[id]).find(Boolean);
            const isSel = key === selected;
            const isToday = key === todayKey;
            return (
              <button
                key={idx}
                onClick={() => setSelected(key)}
                className="aspect-square rounded-[10px] relative overflow-hidden flex items-center justify-center w-press w-fade"
                style={{
                  backgroundColor: isSel ? C.invBg : dayEntry && !firstPhoto ? C.wash : "transparent",
                  animationDelay: `${Math.min(idx * 8, 200)}ms`,
                }}
              >
                {firstPhoto && !isSel && (
                  <img src={firstPhoto} alt="" className="absolute inset-0 w-full h-full object-cover" style={{ opacity: 0.95 }} />
                )}
                <span
                  className="text-[11px] relative z-10"
                  style={{
                    color: isSel ? C.invText : firstPhoto ? "#fff" : isToday ? C.accent : C.text,
                    fontWeight: isToday || isSel ? 600 : 400,
                    textShadow: firstPhoto && !isSel ? "0 1px 4px rgba(0,0,0,0.8)" : "none",
                  }}
                >
                  {d}
                </span>
              </button>
            );
          })}
        </div>
      </Panel>

      <Panel style={{ padding: 18 }} className="mt-3" delay={120}>
        <Eyebrow>
          {parseYmd(selected).toLocaleDateString("default", { weekday: "long", month: "long", day: "numeric" })}
        </Eyebrow>
        {selectedItems.length > 0 ? (
          <>
            <div className="space-y-3.5 mt-3">
              {selectedItems.map((it, i) => (
                <button
                  key={it.id}
                  onClick={() => onOpenItem(it)}
                  className="flex items-center gap-3 w-full text-left w-press w-in"
                  style={{ animationDelay: `${i * 45}ms` }}
                >
                  <Thumb item={it} photo={photos[it.id]} size={44} radius={11} />
                  <div>
                    <p className="text-[13px] font-medium" style={{ color: C.text }}>
                      {it.name}
                    </p>
                    <p className="text-[12px] mt-0.5" style={{ color: C.faint }}>
                      {it.brand} · {it.category}
                    </p>
                  </div>
                </button>
              ))}
            </div>
            {entry?.note && (
              <p className="text-[13px] mt-4 pt-4" style={{ color: C.sub, borderTop: `1px solid ${C.line}` }}>
                {entry.note}
              </p>
            )}
            <button onClick={() => onLogFor(selected)} className="text-[13px] font-medium mt-4 w-press" style={{ color: C.accent }}>
              Edit
            </button>
          </>
        ) : (
          <>
            <p className="text-[13px] mt-1" style={{ color: C.sub }}>
              {isFuture ? "Hasn't happened yet." : "Nothing logged."}
            </p>
            {!isFuture && (
              <button onClick={() => onLogFor(selected)} className="text-[13px] font-medium mt-2.5 w-press" style={{ color: C.accent }}>
                Log an outfit
              </button>
            )}
          </>
        )}
      </Panel>
    </div>
  );
}

/* ══════════════════════════ Heatmap ══════════════════════════ */
function Heatmap({ outfitLog }) {
  const today = new Date();
  const gridEnd = addDays(today, 6 - today.getDay());
  const gridStart = addDays(gridEnd, -(17 * 7 - 1));

  const weeks = [];
  for (let w = 0; w < 17; w++) {
    const days = [];
    for (let d = 0; d < 7; d++) {
      const date = addDays(gridStart, w * 7 + d);
      const entry = outfitLog[ymd(date)];
      days.push({ date, count: entry?.items?.length || 0, future: date > today });
    }
    weeks.push(days);
  }

  const shade = (n, future) => {
    if (future) return "transparent";
    if (n === 0) return "var(--w-heat-0)";
    if (n <= 1) return "var(--w-heat-1)";
    if (n <= 2) return "var(--w-heat-2)";
    if (n <= 3) return "var(--w-heat-3)";
    return "var(--w-heat-4)";
  };

  return (
    <div>
      <div className="flex gap-[3px] justify-between">
        {weeks.map((week, wi) => (
          <div key={wi} className="flex flex-col gap-[3px] w-fade" style={{ animationDelay: `${wi * 18}ms` }}>
            {week.map((day, di) => (
              <div
                key={di}
                title={`${ymd(day.date)} — ${day.count} item${day.count === 1 ? "" : "s"}`}
                className="rounded-[2px]"
                style={{ width: 11, height: 11, backgroundColor: shade(day.count, day.future) }}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between mt-3.5">
        <p className="text-[11px]" style={{ color: C.faint }}>
          17 weeks
        </p>
        <div className="flex items-center gap-1.5">
          <span className="text-[11px]" style={{ color: C.faint }}>
            Less
          </span>
          {["var(--w-heat-0)", "var(--w-heat-1)", "var(--w-heat-2)", "var(--w-heat-3)", "var(--w-heat-4)"].map((c) => (
            <div key={c} className="rounded-[2px]" style={{ width: 9, height: 9, backgroundColor: c }} />
          ))}
          <span className="text-[11px]" style={{ color: C.faint }}>
            More
          </span>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════ Stats ══════════════════════════ */
const PIE_LIGHT = ["#111827", "#3B82F6", "#6B7280", "#93C5FD", "#D1D5DB", "#1E3A8A", "#9CA3AF", "#BFDBFE", "#374151"];
const PIE_DARK = ["#F2F2F0", "#6BA5FB", "#A3A3A8", "#3E6FB8", "#4A4A52", "#BFD9FF", "#6B6B72", "#25476F", "#8A8A92"];

function StatsScreen({ items, photos, outfitLog, onOpenItem, dark }) {
  const PIE_COLORS = dark ? PIE_DARK : PIE_LIGHT;
  if (items.length === 0) {
    return (
      <div className="px-5 pt-3 pb-8">
        <h1 className="text-[28px] font-medium tracking-tight leading-none w-in" style={{ color: C.text }}>
          Stats
        </h1>
        <Panel style={{ padding: 24 }} className="mt-6" delay={60}>
          <p className="text-[13px] leading-relaxed" style={{ color: C.sub }}>
            Add clothes and log a few outfits. Cost-per-wear, streaks, and wear patterns show up here.
          </p>
        </Panel>
      </div>
    );
  }

  const totalSpent = items.reduce((s, i) => s + (Number(i.price) || 0), 0);
  const totalWears = items.reduce((s, i) => s + i.wears, 0);
  const avgCPW = totalWears > 0 ? totalSpent / totalWears : 0;

  const priced = items.filter((i) => i.wears > 0 && Number(i.price) > 0);
  const bestValue = [...priced].sort((a, b) => a.price / a.wears - b.price / b.wears).slice(0, 3);
  const worstValue = [...priced].sort((a, b) => b.price / b.wears - a.price / a.wears).slice(0, 3);
  const mostWorn = items.filter((i) => i.wears > 0).sort((a, b) => b.wears - a.wears).slice(0, 5);
  const leastWorn = [...items].sort((a, b) => (daysSince(b.lastWorn) ?? 9999) - (daysSince(a.lastWorn) ?? 9999)).slice(0, 5);
  const catCounts = CATEGORIES.map((cat) => ({ name: cat, value: items.filter((i) => i.category === cat).length })).filter(
    (c) => c.value > 0
  );

  const Row = ({ item, right, i }) => (
    <button
      onClick={() => onOpenItem(item)}
      className="flex items-center gap-3 px-4 py-3 w-full text-left w-press"
      style={{ borderTop: i > 0 ? `1px solid ${C.line}` : "none" }}
    >
      <Thumb item={item} photo={photos[item.id]} size={36} radius={9} />
      <p className="text-[13px] flex-1 leading-snug" style={{ color: C.text }}>
        {item.name}
      </p>
      {right}
    </button>
  );

  return (
    <div className="px-5 pt-3 pb-8">
      <h1 className="text-[28px] font-medium tracking-tight leading-none w-in" style={{ color: C.text }}>
        Stats
      </h1>

      <div className="grid grid-cols-2 gap-3 mt-6">
        <Panel style={{ padding: 18 }} delay={60}>
          <Eyebrow>Cost per wear</Eyebrow>
          <p className="text-[26px] font-medium tracking-tight leading-none" style={{ color: C.text }}>
            ${avgCPW.toFixed(2)}
          </p>
        </Panel>
        <Panel style={{ padding: 18 }} delay={100}>
          <Eyebrow>Total wears</Eyebrow>
          <p className="text-[26px] font-medium tracking-tight leading-none" style={{ color: C.text }}>
            {totalWears}
          </p>
        </Panel>
      </div>

      <Panel style={{ padding: 18 }} className="mt-3" delay={150}>
        <Eyebrow>Consistency</Eyebrow>
        <Heatmap outfitLog={outfitLog} />
      </Panel>

      {bestValue.length > 0 && (
        <div className="mt-6">
          <Eyebrow className="px-1">Best value</Eyebrow>
          <Panel style={{ padding: 0 }} delay={200}>
            {bestValue.map((it, i) => (
              <Row
                key={it.id}
                item={it}
                i={i}
                right={
                  <div className="text-right">
                    <p className="text-[13px] font-medium" style={{ color: C.text }}>
                      ${(it.price / it.wears).toFixed(2)}
                    </p>
                    <p className="text-[11px] mt-0.5" style={{ color: C.faint }}>
                      {it.wears} wears
                    </p>
                  </div>
                }
              />
            ))}
          </Panel>
        </div>
      )}

      {worstValue.length > 0 && (
        <div className="mt-6">
          <Eyebrow className="px-1">Costing you most</Eyebrow>
          <Panel style={{ padding: 0 }} delay={240}>
            {worstValue.map((it, i) => (
              <Row
                key={it.id}
                item={it}
                i={i}
                right={
                  <div className="text-right">
                    <p className="text-[13px] font-medium" style={{ color: C.warning }}>
                      ${(it.price / it.wears).toFixed(2)}
                    </p>
                    <p className="text-[11px] mt-0.5" style={{ color: C.faint }}>
                      {it.wears} wears
                    </p>
                  </div>
                }
              />
            ))}
          </Panel>
        </div>
      )}

      {mostWorn.length > 0 && (
        <div className="mt-6">
          <Eyebrow className="px-1">Most worn</Eyebrow>
          <Panel style={{ padding: 0 }} delay={280}>
            {mostWorn.map((it, i) => (
              <Row
                key={it.id}
                item={it}
                i={i}
                right={
                  <p className="text-[13px] font-medium" style={{ color: C.text }}>
                    {it.wears}
                  </p>
                }
              />
            ))}
          </Panel>
        </div>
      )}

      <div className="mt-6">
        <Eyebrow className="px-1">Forgotten</Eyebrow>
        <Panel style={{ padding: 0 }} delay={320}>
          {leastWorn.map((it, i) => (
            <Row
              key={it.id}
              item={it}
              i={i}
              right={
                <p className="text-[12px]" style={{ color: C.faint }}>
                  {lastWornLabel(it.lastWorn)}
                </p>
              }
            />
          ))}
        </Panel>
      </div>

      <div className="mt-6">
        <Eyebrow className="px-1">Categories</Eyebrow>
        <Panel style={{ padding: 18 }} delay={360}>
          <div style={{ width: "100%", height: 165 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={catCounts} dataKey="value" nameKey="name" innerRadius={46} outerRadius={70} paddingAngle={3} stroke="none">
                  {catCounts.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-2 mt-3">
            {catCounts.map((c, i) => (
              <div key={c.name} className="flex items-center gap-2">
                <span className="rounded-full shrink-0" style={{ width: 7, height: 7, backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }} />
                <span className="text-[12px]" style={{ color: C.sub }}>
                  {c.name}s
                </span>
                <span className="text-[12px] ml-auto" style={{ color: C.faint }}>
                  {c.value}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

/* ══════════════════════════ Profile ══════════════════════════ */
function ProfileScreen({ items, outfitLog, streak, onReset, dark, onToggleTheme }) {
  const totalSpent = items.reduce((s, i) => s + (Number(i.price) || 0), 0);
  const totalWears = items.reduce((s, i) => s + i.wears, 0);
  const avgCPW = totalWears > 0 ? totalSpent / totalWears : 0;
  const priced = items.filter((i) => Number(i.price) > 0);
  const mostExpensive = priced.length ? [...priced].sort((a, b) => b.price - a.price)[0] : null;
  const best = longestStreak(outfitLog);
  const outfitCount = Object.keys(outfitLog).length;

  const uniqueLast7 = (() => {
    const set = new Set();
    for (let i = 0; i < 7; i++) {
      const e = outfitLog[ymd(addDays(new Date(), -i))];
      if (e) set.add([...e.items].sort().join("|"));
    }
    return set.size;
  })();

  const badges = [
    { name: "First outfit", earned: outfitCount >= 1 },
    { name: "100 wears", earned: totalWears >= 100 },
    { name: "30-day streak", earned: best >= 30 },
    { name: "No-repeat week", earned: uniqueLast7 >= 7 },
    { name: "Closet master", earned: items.length >= 25 },
    { name: "Collector", earned: items.length >= 50 },
    { name: "Minimalist", earned: items.length > 0 && items.length <= 20 },
  ];

  const stats = [
    ["Clothes", items.length],
    ["Spent", `$${totalSpent.toLocaleString()}`],
    ["Cost / wear", `$${avgCPW.toFixed(2)}`],
    ["Outfits", outfitCount],
    ["Longest streak", `${best}d`],
    ["Priciest", mostExpensive ? mostExpensive.name : "—"],
  ];

  return (
    <div className="px-5 pt-3 pb-8">
      <h1 className="text-[28px] font-medium tracking-tight leading-none w-in" style={{ color: C.text }}>
        Profile
      </h1>
      <p className="text-[13px] mt-2 w-in" style={{ color: C.faint, animationDelay: "40ms" }}>
        {streak > 0 ? `${streak}-day streak going` : "No active streak"}
      </p>

      <Panel style={{ padding: 0 }} className="mt-6 overflow-hidden" delay={80}>
        {stats.map(([label, value], i) => (
          <div
            key={label}
            className="flex items-center justify-between px-4 py-3.5"
            style={{ borderTop: i > 0 ? `1px solid ${C.line}` : "none" }}
          >
            <span className="text-[13px]" style={{ color: C.sub }}>
              {label}
            </span>
            <span className="text-[13px] font-medium" style={{ color: C.text }}>
              {value}
            </span>
          </div>
        ))}
      </Panel>

      <div className="mt-6">
        <Eyebrow className="px-1">Badges</Eyebrow>
        <div className="flex flex-wrap gap-2">
          {badges.map((b, i) => (
            <div
              key={b.name}
              className="px-3 py-1.5 rounded-full text-[12px] w-in"
              style={{
                backgroundColor: b.earned ? C.invBg : "transparent",
                color: b.earned ? C.invText : C.faint,
                border: `1px solid ${b.earned ? C.invBg : C.line}`,
                animationDelay: `${120 + i * 40}ms`,
              }}
            >
              {b.name}
            </div>
          ))}
        </div>
      </div>

      <Panel style={{ padding: 20, backgroundColor: C.invBg, border: "none" }} className="mt-6" delay={200}>
        <div className="flex items-start justify-between">
          <div>
            <p className="text-[15px] font-medium" style={{ color: C.invText }}>Premium</p>
            <p className="text-[12px] mt-1" style={{ color: "#9CA3AF" }}>
              $4.99 / month
            </p>
          </div>
          <ArrowUpRight size={17} color="#9CA3AF" />
        </div>
        <div className="mt-4 space-y-2">
          {["Unlimited items", "AI outfit recommendations", "Weather-based suggestions", "Shared closets and backup"].map((f) => (
            <p key={f} className="text-[12px]" style={{ color: "#D1D5DB" }}>
              {f}
            </p>
          ))}
        </div>
        <button className="w-full mt-5 rounded-xl py-2.5 text-[13px] font-medium w-press" style={{ backgroundColor: C.bg, color: C.text }}>
          Upgrade
        </button>
      </Panel>

      <div className="mt-6">
        <Eyebrow className="px-1">Data</Eyebrow>
        <Panel style={{ padding: 0 }} delay={240}>
          <button onClick={onToggleTheme} className="flex items-center gap-3 px-4 py-3.5 w-full text-left w-press">
            {dark ? <Sun size={16} color={C.faint} strokeWidth={1.6} /> : <Moon size={16} color={C.faint} strokeWidth={1.6} />}
            <span className="text-[13px]" style={{ color: C.text }}>
              {dark ? "Light mode" : "Dark mode"}
            </span>
          </button>
          <button
            onClick={onReset}
            className="flex items-center gap-3 px-4 py-3.5 w-full text-left w-press"
            style={{ borderTop: `1px solid ${C.line}` }}
          >
            <RotateCcw size={16} color={C.danger} strokeWidth={1.6} />
            <span className="text-[13px]" style={{ color: C.danger }}>
              Clear everything
            </span>
          </button>
        </Panel>
        <p className="text-[11px] mt-2.5 px-1 leading-relaxed" style={{ color: C.faint }}>
          Saved to this browser. Nothing leaves your device except photos you choose to scan.
        </p>
      </div>
    </div>
  );
}

/* ══════════════════════════ Sheets ══════════════════════════ */
function Sheet({ children, onClose, title, maxHeight = "90%" }) {
  return (
    <div className="fixed inset-0 z-30 flex flex-col justify-end w-fade" style={{ backgroundColor: "var(--w-scrim)" }} onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-[460px] mx-auto rounded-t-[28px] px-5 pt-5 pb-8 overflow-y-auto w-sheet w-scroll"
        style={{ backgroundColor: C.bg, maxHeight }}
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-[17px] font-medium tracking-tight" style={{ color: C.text }}>
            {title}
          </h2>
          <button onClick={onClose} className="p-1 w-press">
            <X size={19} color={C.faint} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function LogOutfitSheet({ items, photos, dateKey, initial, onClose, onSave }) {
  const [selected, setSelected] = useState(initial?.items || []);
  const [note, setNote] = useState(initial?.note || "");
  const toggle = (id) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const groups = [
    { label: "Top", list: items.filter((i) => TOP_CATS.includes(i.category)) },
    { label: "Bottom", list: items.filter((i) => BOTTOM_CATS.includes(i.category)) },
    { label: "Shoes", list: items.filter((i) => SHOE_CATS.includes(i.category)) },
    { label: "Layers", list: items.filter((i) => ACCESSORY_CATS.includes(i.category)) },
  ].filter((g) => g.list.length > 0);

  return (
    <Sheet onClose={onClose} title="Log outfit">
      <p className="text-[13px] -mt-3 mb-5" style={{ color: C.faint }}>
        {parseYmd(dateKey).toLocaleDateString("default", { weekday: "long", month: "long", day: "numeric" })}
      </p>
      {groups.map((g, gi) => (
        <div key={g.label} className="mb-5 w-in" style={{ animationDelay: `${gi * 50}ms` }}>
          <Eyebrow>{g.label}</Eyebrow>
          <div className="flex gap-2.5 overflow-x-auto w-scroll pb-1 pt-1">
            {g.list.map((it) => {
              const on = selected.includes(it.id);
              return (
                <button key={it.id} onClick={() => toggle(it.id)} className="shrink-0 w-press" style={{ width: 66 }}>
                  <div className="relative">
                    <div
                      style={{
                        outline: on ? `2px solid ${C.accent}` : "none",
                        outlineOffset: 2,
                        borderRadius: 13,
                        transition: "outline-color .18s ease",
                      }}
                    >
                      <Thumb item={it} photo={photos[it.id]} size={66} radius={13} />
                    </div>
                    {on && (
                      <div
                        className="absolute -top-1.5 -right-1.5 rounded-full flex items-center justify-center w-pop"
                        style={{ width: 20, height: 20, backgroundColor: C.accent, border: `2px solid ${C.bg}` }}
                      >
                        <Check size={10} color={C.onAccent} strokeWidth={3.5} />
                      </div>
                    )}
                  </div>
                  <p className="text-[10px] text-center leading-tight mt-2" style={{ color: on ? C.text : C.faint }}>
                    {it.name}
                  </p>
                </button>
              );
            })}
          </div>
        </div>
      ))}

      <input
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Note — weather, occasion, how it felt"
        className="w-full rounded-xl px-3.5 py-3 text-[14px] outline-none mb-4"
        style={{ backgroundColor: C.card, border: `1px solid ${C.line}`, color: C.text }}
      />

      <PrimaryButton disabled={selected.length === 0} onClick={() => onSave({ items: selected, note: note.trim() })} tone="dark">
        {selected.length === 0 ? "Pick at least one" : `Save · ${selected.length} item${selected.length === 1 ? "" : "s"}`}
      </PrimaryButton>
    </Sheet>
  );
}

const emptyForm = {
  name: "", brand: "", category: "Hoodie", color: "", size: "",
  purchaseDate: "", price: "", season: "All-season", condition: "Good",
  notes: "", favorite: false,
};

function ItemFormSheet({ initialItem, initialPhoto, onClose, onSave, onDelete }) {
  const [form, setForm] = useState(
    initialItem
      ? {
          name: initialItem.name, brand: initialItem.brand, category: initialItem.category,
          color: initialItem.color || "", size: initialItem.size || "",
          purchaseDate: initialItem.purchaseDate || "", price: initialItem.price ? String(initialItem.price) : "",
          season: initialItem.season || "All-season", condition: initialItem.condition || "Good",
          notes: initialItem.notes || "", favorite: !!initialItem.favorite,
        }
      : emptyForm
  );
  const [photo, setPhoto] = useState(initialPhoto || null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [filled, setFilled] = useState([]);
  const [priceBasis, setPriceBasis] = useState("");
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const applyScan = (r) => {
    const touched = [];
    setForm((f) => {
      const next = { ...f };
      if (r.category && CATEGORIES.includes(r.category)) {
        next.category = r.category;
        touched.push("category");
      }
      if (r.color && !f.color) {
        next.color = r.color;
        touched.push("color");
      }
      if (r.brand && !f.brand) {
        next.brand = r.brand;
        touched.push("brand");
      }
      if (r.name && !f.name) {
        next.name = r.name.replace(/\b\w/g, (c) => c.toUpperCase());
        touched.push("name");
      }
      if (r.season && SEASONS.includes(r.season) && f.season === "All-season") {
        next.season = r.season;
        touched.push("season");
      }
      if (r.material && !f.notes) {
        next.notes = r.material;
        touched.push("notes");
      }
      if (r.price && !f.price) {
        next.price = String(r.price);
        touched.push("price");
      }
      return next;
    });
    setPriceBasis(r.price ? r.priceBasis || "typical" : "");
    setFilled(touched);
    setTimeout(() => setFilled([]), 2600);
  };

  const fieldStyle = (key) => ({
    backgroundColor: C.card,
    border: `1px solid ${filled.includes(key) ? C.accent : C.line}`,
    color: C.text,
    transition: "border-color .5s ease",
  });
  const cls = "rounded-xl px-3.5 py-3 text-[14px] outline-none w-full";

  return (
    <Sheet onClose={onClose} title={initialItem ? "Edit item" : "Add clothing"}>
      <PhotoPicker value={photo} onChange={setPhoto} onScanResult={applyScan} />

      <div className="space-y-2.5 mt-5">
        <input placeholder="Name" value={form.name} onChange={(e) => set("name", e.target.value)} className={cls} style={fieldStyle("name")} />
        <div className="grid grid-cols-2 gap-2.5">
          <input placeholder="Brand" value={form.brand} onChange={(e) => set("brand", e.target.value)} className={cls} style={fieldStyle("brand")} />
          <select value={form.category} onChange={(e) => set("category", e.target.value)} className={cls} style={fieldStyle("category")}>
            {CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          <input placeholder="Colour" value={form.color} onChange={(e) => set("color", e.target.value)} className={cls} style={fieldStyle("color")} />
          <input placeholder="Size" value={form.size} onChange={(e) => set("size", e.target.value)} className={cls} style={fieldStyle("size")} />
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <p className="text-[11px] mb-1.5 px-1" style={{ color: C.faint }}>
              Bought
            </p>
            <input type="date" value={form.purchaseDate} onChange={(e) => set("purchaseDate", e.target.value)} className={cls} style={fieldStyle("date")} />
          </div>
          <div>
            <p className="text-[11px] mb-1.5 px-1" style={{ color: C.faint }}>
              Price paid
            </p>
            <input
              type="number"
              inputMode="decimal"
              placeholder="0"
              value={form.price}
              onChange={(e) => {
                set("price", e.target.value);
                setPriceBasis("");
              }}
              className={cls}
              style={fieldStyle("price")}
            />
          </div>
        </div>
        {priceBasis && (
          <p className="text-[11px] px-1 leading-snug w-in" style={{ color: C.warning }}>
            {priceBasis === "tag"
              ? "Read off the price tag in your photo."
              : priceBasis === "retail"
              ? "Current retail price found online — change it to what you actually paid."
              : "Typical retail for this kind of item — change it to what you actually paid."}
          </p>
        )}
        <div className="grid grid-cols-2 gap-2.5">
          <select value={form.season} onChange={(e) => set("season", e.target.value)} className={cls} style={fieldStyle("season")}>
            {SEASONS.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
          <select value={form.condition} onChange={(e) => set("condition", e.target.value)} className={cls} style={fieldStyle("condition")}>
            {CONDITIONS.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </div>
        <textarea
          placeholder="Notes"
          value={form.notes}
          onChange={(e) => set("notes", e.target.value)}
          rows={2}
          className={`${cls} resize-none`}
          style={fieldStyle("notes")}
        />
        <button onClick={() => set("favorite", !form.favorite)} className="flex items-center gap-2 text-[13px] px-1 pt-1 w-press" style={{ color: form.favorite ? C.warning : C.faint }}>
          <Star size={15} fill={form.favorite ? C.warning : "none"} />
          {form.favorite ? "Favourite" : "Mark as favourite"}
        </button>
      </div>

      <div className="mt-6 space-y-2.5">
        <PrimaryButton disabled={!form.name.trim()} onClick={() => onSave(form, photo)} tone="dark">
          {initialItem ? "Save changes" : "Save to closet"}
        </PrimaryButton>
        {initialItem &&
          (confirmDelete ? (
            <div className="flex gap-2.5 w-in">
              <button
                onClick={() => setConfirmDelete(false)}
                className="flex-1 rounded-2xl py-3 text-[13px] w-press"
                style={{ border: `1px solid ${C.line}`, color: C.text }}
              >
                Keep
              </button>
              <button
                onClick={onDelete}
                className="flex-1 rounded-2xl py-3 text-[13px] font-medium text-white w-press"
                style={{ backgroundColor: C.danger }}
              >
                Delete for good
              </button>
            </div>
          ) : (
            <QuietButton onClick={() => setConfirmDelete(true)} icon={Trash2}>
              Delete item
            </QuietButton>
          ))}
      </div>
    </Sheet>
  );
}

function ItemDetailSheet({ item, photo, outfitLog, onClose, onEdit, onWearToday }) {
  const cpw = item.wears > 0 && item.price > 0 ? item.price / item.wears : null;
  const recent = Object.keys(outfitLog)
    .filter((k) => outfitLog[k].items.includes(item.id))
    .sort()
    .reverse()
    .slice(0, 6);
  const wornToday = outfitLog[ymd(new Date())]?.items?.includes(item.id);

  const facts = [
    ["Brand", item.brand], ["Category", item.category], ["Colour", item.color],
    ["Size", item.size], ["Season", item.season], ["Condition", item.condition],
    ["Paid", item.price ? `$${item.price}` : ""], ["Bought", item.purchaseDate],
  ].filter(([, v]) => v);

  return (
    <Sheet onClose={onClose} title={item.name}>
      {photo ? (
        <img src={photo} alt={item.name} className="w-full object-cover rounded-2xl w-fade" style={{ height: 230 }} />
      ) : (
        <div className="flex items-center justify-center rounded-2xl" style={{ height: 160, backgroundColor: C.wash }}>
          <ShirtIcon size={40} color={C.faint} strokeWidth={1.2} />
        </div>
      )}

      <div className="grid grid-cols-3 gap-2.5 mt-4">
        {[
          ["Wears", item.wears],
          ["Per wear", cpw ? `$${cpw.toFixed(2)}` : "—"],
          ["Last worn", lastWornLabel(item.lastWorn)],
        ].map(([label, value], i) => (
          <Panel key={label} style={{ padding: 14 }} delay={i * 50}>
            <p className="text-[10px] uppercase" style={{ color: C.faint, letterSpacing: "0.08em" }}>
              {label}
            </p>
            <p className="text-[14px] font-medium mt-1.5 leading-tight" style={{ color: C.text }}>
              {value}
            </p>
          </Panel>
        ))}
      </div>

      <Panel style={{ padding: 0 }} className="mt-3" delay={150}>
        {facts.map(([k, v], i) => (
          <div key={k} className="flex justify-between px-4 py-3 text-[13px]" style={{ borderTop: i > 0 ? `1px solid ${C.line}` : "none" }}>
            <span style={{ color: C.faint }}>{k}</span>
            <span style={{ color: C.text }}>{v}</span>
          </div>
        ))}
      </Panel>

      {item.notes && (
        <Panel style={{ padding: 16 }} className="mt-3" delay={190}>
          <p className="text-[13px] leading-relaxed" style={{ color: C.sub }}>
            {item.notes}
          </p>
        </Panel>
      )}

      {recent.length > 0 && (
        <div className="mt-6">
          <Eyebrow className="px-1">Recently worn</Eyebrow>
          <div className="flex flex-wrap gap-2">
            {recent.map((d, i) => (
              <span
                key={d}
                className="px-3 py-1.5 rounded-full text-[12px] w-in"
                style={{ border: `1px solid ${C.line}`, color: C.sub, animationDelay: `${i * 40}ms` }}
              >
                {parseYmd(d).toLocaleDateString("default", { month: "short", day: "numeric" })}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="mt-6 space-y-2.5">
        <PrimaryButton onClick={onWearToday} disabled={wornToday} tone="dark">
          {wornToday ? "Already worn today" : "Wearing this today"}
        </PrimaryButton>
        <QuietButton onClick={onEdit} icon={Pencil}>
          Edit details
        </QuietButton>
      </div>
    </Sheet>
  );
}

/* ══════════════════════════ Root ══════════════════════════ */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    console.error("Worn crashed:", error, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: C.bg }}>
          <div className="max-w-[380px]">
            <p className="text-[15px] font-medium" style={{ color: C.text }}>
              Something broke while rendering
            </p>
            <p className="text-[13px] mt-2 leading-relaxed" style={{ color: C.sub }}>
              The error is below — send it over and it can be fixed.
            </p>
            <pre
              className="text-[11px] mt-4 p-3 rounded-xl overflow-auto whitespace-pre-wrap"
              style={{ backgroundColor: C.card, border: `1px solid ${C.line}`, color: C.danger, maxHeight: 220 }}
            >
              {String(this.state.error?.message || this.state.error)}
            </pre>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function WornApp() {
  const [items, setItems] = useState([]);
  const [outfitLog, setOutfitLog] = useState({});
  const [photos, setPhotos] = useState({});
  const [loading, setLoading] = useState(true);
  const [screen, setScreen] = useState("home");
  const [toast, setToast] = useState(null);
  const [logSheet, setLogSheet] = useState(null);
  const [formSheet, setFormSheet] = useState(null);
  const [detailItem, setDetailItem] = useState(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const [dark, setDark] = useState(false);
  const [fabOpen, setFabOpen] = useState(false);

  const showToast = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const raw = await safeGet(DATA_KEY);
        if (raw && !cancelled) {
          try {
            const parsed = JSON.parse(raw);
            setItems(Array.isArray(parsed.items) ? parsed.items : []);
            setOutfitLog(parsed.outfitLog && typeof parsed.outfitLog === "object" ? parsed.outfitLog : {});
          } catch {
            /* corrupt payload — start fresh */
          }
        }
        const buckets = await Promise.all(Array.from({ length: PHOTO_BUCKETS }, (_, b) => safeGet(photoKey(b))));
        if (cancelled) return;
        const merged = {};
        buckets.forEach((r) => {
          if (!r) return;
          try {
            Object.assign(merged, JSON.parse(r));
          } catch {
            /* skip bad bucket */
          }
        });
        setPhotos(merged);

        const savedTheme = await safeGet(THEME_KEY);
        if (!cancelled) {
          if (savedTheme === "dark" || savedTheme === "light") {
            setDark(savedTheme === "dark");
          } else if (typeof window !== "undefined" && window.matchMedia) {
            setDark(window.matchMedia("(prefers-color-scheme: dark)").matches);
          }
        }
      } catch (e) {
        console.error("Load failed", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const persistData = useCallback(
    async (nextItems, nextLog) => {
      const ok = await safeSet(DATA_KEY, JSON.stringify({ items: nextItems, outfitLog: nextLog }));
      if (!ok) showToast("Couldn't save — closet may be too large");
    },
    [showToast]
  );

  const persistPhoto = useCallback(
    async (itemId, dataUrl, currentPhotos) => {
      const b = bucketFor(itemId);
      const bucket = {};
      Object.entries(currentPhotos).forEach(([id, p]) => {
        if (bucketFor(id) === b) bucket[id] = p;
      });
      if (dataUrl) bucket[itemId] = dataUrl;
      else delete bucket[itemId];
      const ok = await safeSet(photoKey(b), JSON.stringify(bucket));
      if (!ok) showToast("Photo couldn't be saved — try a smaller image");
    },
    [showToast]
  );

  const streak = useMemo(() => computeStreak(outfitLog), [outfitLog]);

  const saveOutfit = async (dateKey, entry) => {
    const prevIds = outfitLog[dateKey]?.items || [];
    const nextIds = entry.items;
    const added = nextIds.filter((id) => !prevIds.includes(id));
    const removed = prevIds.filter((id) => !nextIds.includes(id));

    const nextLog = { ...outfitLog, [dateKey]: entry };
    if (nextIds.length === 0) delete nextLog[dateKey];

    const nextItems = items.map((it) => {
      let wears = it.wears;
      let lastWorn = it.lastWorn;
      if (added.includes(it.id)) {
        wears += 1;
        if (!lastWorn || dateKey > lastWorn) lastWorn = dateKey;
      }
      if (removed.includes(it.id)) {
        wears = Math.max(0, wears - 1);
        if (lastWorn === dateKey) {
          const dates = Object.keys(nextLog).filter((k) => nextLog[k].items.includes(it.id)).sort();
          lastWorn = dates.length ? dates[dates.length - 1] : null;
        }
      }
      return wears === it.wears && lastWorn === it.lastWorn ? it : { ...it, wears, lastWorn };
    });

    setItems(nextItems);
    setOutfitLog(nextLog);
    setLogSheet(null);
    await persistData(nextItems, nextLog);
    showToast(nextIds.length ? "Outfit logged" : "Outfit cleared");
  };

  const wearToday = async (item) => {
    const key = ymd(new Date());
    const existing = outfitLog[key];
    if (existing?.items.includes(item.id)) return;
    setDetailItem(null);
    await saveOutfit(key, { items: [...(existing?.items || []), item.id], note: existing?.note || "" });
  };

  const saveItem = async (form, photo, existing) => {
    const id = existing?.id || `it_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const record = {
      id,
      name: form.name.trim(),
      brand: form.brand.trim() || "Unbranded",
      category: form.category,
      color: form.color.trim(),
      size: form.size.trim(),
      purchaseDate: form.purchaseDate,
      price: Number(form.price) || 0,
      season: form.season,
      condition: form.condition,
      notes: form.notes.trim(),
      favorite: form.favorite,
      wears: existing?.wears ?? 0,
      lastWorn: existing?.lastWorn ?? null,
      createdAt: existing?.createdAt ?? Date.now(),
    };
    const nextItems = existing ? items.map((i) => (i.id === id ? record : i)) : [record, ...items];
    const nextPhotos = { ...photos };
    if (photo) nextPhotos[id] = photo;
    else delete nextPhotos[id];

    setItems(nextItems);
    setPhotos(nextPhotos);
    setFormSheet(null);
    setDetailItem(null);
    await persistData(nextItems, outfitLog);
    await persistPhoto(id, photo, nextPhotos);
    showToast(existing ? "Saved" : `${record.name} added`);
  };

  const deleteItem = async (item) => {
    const nextItems = items.filter((i) => i.id !== item.id);
    const nextLog = {};
    Object.entries(outfitLog).forEach(([k, v]) => {
      const kept = v.items.filter((id) => id !== item.id);
      if (kept.length) nextLog[k] = { ...v, items: kept };
    });
    const nextPhotos = { ...photos };
    delete nextPhotos[item.id];

    setItems(nextItems);
    setOutfitLog(nextLog);
    setPhotos(nextPhotos);
    setFormSheet(null);
    setDetailItem(null);
    await persistData(nextItems, nextLog);
    await persistPhoto(item.id, null, nextPhotos);
    showToast(`${item.name} deleted`);
  };

  const toggleTheme = async () => {
    const next = !dark;
    setDark(next);
    await safeSet(THEME_KEY, next ? "dark" : "light");
  };

  const resetAll = async () => {
    setItems([]);
    setOutfitLog({});
    setPhotos({});
    setConfirmReset(false);
    setScreen("home");
    await persistData([], {});
    for (let b = 0; b < PHOTO_BUCKETS; b++) await safeSet(photoKey(b), "{}");
    showToast("Everything cleared");
  };

  const NAV = [
    { id: "home", label: "Home", icon: HomeIcon },
    { id: "closet", label: "Closet", icon: ShirtIcon },
    { id: "calendar", label: "Calendar", icon: CalendarIcon },
    { id: "stats", label: "Stats", icon: BarChart3 },
  ];

  const liveDetail = detailItem ? items.find((i) => i.id === detailItem.id) || detailItem : null;

  if (loading) {
    return (
      <>
        <style dangerouslySetInnerHTML={{ __html: MOTION_CSS }} />
        <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: C.bg }}>
          <Loader2 size={20} color={C.faint} style={{ animation: "wSpin 1s linear infinite" }} />
        </div>
      </>
    );
  }

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: MOTION_CSS }} />
      <div className={`min-h-screen ${dark ? "w-dark" : "w-light"}`} style={{ backgroundColor: C.bg, fontFamily: "'Inter', -apple-system, system-ui, sans-serif", transition: "background-color .3s ease" }}>
        <div className="max-w-[460px] mx-auto min-h-screen relative">
          {/* Masthead */}
          <div
            className="sticky top-0 z-10 px-5 py-3.5 flex items-center gap-2"
            style={{ backgroundColor: C.veil, backdropFilter: "blur(12px)" }}
          >
            <div className="flex items-center justify-center rounded-[7px]" style={{ width: 22, height: 22, border: `1.5px solid ${C.text}` }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={C.text} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 3v3a3 3 0 0 0 3 3l6 4-1 3H4l-1-3 6-4a3 3 0 0 0 3-3V3Z" />
              </svg>
            </div>
            <span className="text-[13px] font-medium tracking-tight" style={{ color: C.text }}>
              Worn.
            </span>

            <div className="ml-auto flex items-center gap-1">
              <button
                onClick={toggleTheme}
                aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
                className="rounded-full p-2 w-press"
                style={{ color: C.sub }}
              >
                {dark ? <Sun size={17} strokeWidth={1.7} /> : <Moon size={17} strokeWidth={1.7} />}
              </button>
              <button
                onClick={() => setScreen("profile")}
                aria-label="Profile"
                className="rounded-full p-2 w-press"
                style={{ color: screen === "profile" ? C.text : C.sub }}
              >
                <UserIcon size={17} strokeWidth={screen === "profile" ? 2.1 : 1.7} />
              </button>
            </div>
          </div>

          {/* Screens — keyed so each entry animates */}
          <div key={screen} style={{ paddingBottom: 92 }}>
            {screen === "home" && (
              <HomeScreen
                items={items}
                photos={photos}
                outfitLog={outfitLog}
                streak={streak}
                onLogOutfit={() => setLogSheet(ymd(new Date()))}
                onOpenItem={setDetailItem}
                onGoCloset={() => {
                  setScreen("closet");
                  setFormSheet({ mode: "add" });
                }}
              />
            )}
            {screen === "closet" && (
              <ClosetScreen items={items} photos={photos} onAddItem={() => setFormSheet({ mode: "add" })} onOpenItem={setDetailItem} />
            )}
            {screen === "calendar" && (
              <CalendarScreen items={items} photos={photos} outfitLog={outfitLog} onOpenItem={setDetailItem} onLogFor={setLogSheet} />
            )}
            {screen === "stats" && <StatsScreen items={items} photos={photos} outfitLog={outfitLog} onOpenItem={setDetailItem} dark={dark} />}
            {screen === "profile" && (
              <ProfileScreen items={items} outfitLog={outfitLog} streak={streak} onReset={() => setConfirmReset(true)} dark={dark} onToggleTheme={toggleTheme} />
            )}
          </div>

          {/* Nav */}
          <div
            className="fixed bottom-0 w-full max-w-[460px] z-30"
            style={{ height: 80, backgroundColor: C.navVeil, backdropFilter: "blur(14px)", borderTop: `1px solid ${C.line}` }}
          >
            <div className="flex items-center h-full px-1">
              {NAV.map((n, i) => {
                const Icon = n.icon;
                const active = screen === n.id;
                const tab = (
                  <button
                    key={n.id}
                    onClick={() => setScreen(n.id)}
                    className="flex-1 flex flex-col items-center gap-1.5 py-2 w-press"
                  >
                    <Icon size={19} color={active ? C.text : C.faint} strokeWidth={active ? 2 : 1.6} style={{ transition: "color .2s ease" }} />
                    <span
                      className="text-[9px]"
                      style={{ color: active ? C.text : C.faint, fontWeight: active ? 600 : 400, letterSpacing: "0.04em", transition: "color .2s ease" }}
                    >
                      {n.label}
                    </span>
                  </button>
                );

                // Plus sits inline in the middle, same row as the tabs.
                if (i !== 2) return tab;
                return [
                  <button
                    key="add"
                    onClick={() => setFabOpen((o) => !o)}
                    aria-label={fabOpen ? "Close menu" : "Add"}
                    className="flex-1 flex flex-col items-center gap-1.5 py-2 w-press"
                  >
                    <div
                      className="rounded-full flex items-center justify-center w-fab"
                      style={{
                        width: 34,
                        height: 34,
                        backgroundColor: C.accent,
                        color: C.onAccent,
                        transform: `rotate(${fabOpen ? 135 : 0}deg)`,
                      }}
                    >
                      <Plus size={19} strokeWidth={2.4} />
                    </div>
                    <span
                      className="text-[9px]"
                      style={{ color: fabOpen ? C.text : C.faint, fontWeight: fabOpen ? 600 : 400, letterSpacing: "0.04em" }}
                    >
                      Add
                    </span>
                  </button>,
                  tab,
                ];
              })}
            </div>
          </div>

          {/* Quick actions */}
          {fabOpen && (
            <>
              <div className="fixed inset-0 z-20 w-fade" onClick={() => setFabOpen(false)} style={{ backgroundColor: "var(--w-scrim)" }} />
              <div className="fixed bottom-[94px] left-1/2 -translate-x-1/2 z-40 flex flex-col items-center gap-2.5">
                {[
                  {
                    label: "Add clothing",
                    icon: ShirtIcon,
                    onClick: () => {
                      setFabOpen(false);
                      setFormSheet({ mode: "add" });
                    },
                  },
                  {
                    label: "Log today's outfit",
                    icon: CalendarIcon,
                    disabled: items.length === 0,
                    onClick: () => {
                      setFabOpen(false);
                      setLogSheet(ymd(new Date()));
                    },
                  },
                ].map((a, i) => {
                  const Icon = a.icon;
                  return (
                    <button
                      key={a.label}
                      onClick={a.onClick}
                      disabled={a.disabled}
                      className="flex items-center gap-2.5 rounded-full pl-4 pr-5 py-3 text-[13px] font-medium w-press w-rise disabled:opacity-40"
                      style={{
                        backgroundColor: C.card,
                        border: `1px solid ${C.line}`,
                        color: C.text,
                        animationDelay: `${i * 55}ms`,
                        boxShadow: "0 8px 24px rgba(0,0,0,0.14)",
                      }}
                    >
                      <Icon size={16} color={C.accent} strokeWidth={1.8} />
                      {a.label}
                    </button>
                  );
                })}
              </div>
            </>
          )}

          {toast && (
            <div
              className="fixed bottom-[100px] left-1/2 px-4 py-2.5 rounded-full text-[13px] z-40 whitespace-nowrap w-toast"
              style={{ backgroundColor: C.invBg, color: C.invText }}
            >
              {toast}
            </div>
          )}

          {logSheet && (
            <LogOutfitSheet
              items={items}
              photos={photos}
              dateKey={logSheet}
              initial={outfitLog[logSheet]}
              onClose={() => setLogSheet(null)}
              onSave={(entry) => saveOutfit(logSheet, entry)}
            />
          )}
          {formSheet && (
            <ItemFormSheet
              initialItem={formSheet.item}
              initialPhoto={formSheet.item ? photos[formSheet.item.id] : null}
              onClose={() => setFormSheet(null)}
              onSave={(form, photo) => saveItem(form, photo, formSheet.item)}
              onDelete={() => deleteItem(formSheet.item)}
            />
          )}
          {liveDetail && !formSheet && (
            <ItemDetailSheet
              item={liveDetail}
              photo={photos[liveDetail.id]}
              outfitLog={outfitLog}
              onClose={() => setDetailItem(null)}
              onEdit={() => setFormSheet({ mode: "edit", item: liveDetail })}
              onWearToday={() => wearToday(liveDetail)}
            />
          )}
          {confirmReset && (
            <Sheet onClose={() => setConfirmReset(false)} title="Clear everything?" maxHeight="46%">
              <p className="text-[13px] mb-6 leading-relaxed" style={{ color: C.sub }}>
                Removes every item, photo, and logged outfit. Can't be undone.
              </p>
              <div className="flex gap-2.5">
                <button onClick={() => setConfirmReset(false)} className="flex-1 rounded-2xl py-3.5 text-[14px] w-press" style={{ border: `1px solid ${C.line}`, color: C.text }}>
                  Cancel
                </button>
                <button onClick={resetAll} className="flex-1 rounded-2xl py-3.5 text-[14px] font-medium w-press" style={{ backgroundColor: C.danger, color: "#fff" }}>
                  Clear it all
                </button>
              </div>
            </Sheet>
          )}
        </div>
      </div>
    </>
  );
}

export default function Worn() {
  return (
    <ErrorBoundary>
      <WornApp />
    </ErrorBoundary>
  );
}
