import React from "react";
import ReactDOM from "react-dom/client";
import Worn from "./Worn.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Worn />
  </React.StrictMode>
);
