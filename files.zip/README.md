# Worn.

A wardrobe tracker. Photograph your clothes, log what you wear, and find out
which pieces are earning their keep and which have been sitting untouched for
four months.

Everything is stored on the device. There is no account, no server holding your
closet, and nothing syncs anywhere.

---

## Run it locally

You need [Node.js](https://nodejs.org) 18 or newer. Check with `node -v`.

```bash
npm install
npm run dev
```

Open the URL it prints (usually `http://localhost:5173`).

To see the production build before deploying:

```bash
npm run build
npm run preview
```

---

## Deploy it

### Vercel (recommended)

1. Push this folder to a GitHub repository.
2. Go to [vercel.com](https://vercel.com), sign in with GitHub, and click **Add New > Project**.
3. Pick the repository. Vercel detects Vite on its own — leave the build settings alone.
4. Click **Deploy**.

You get a live URL in about a minute. Every push to `main` redeploys.

Vercel is the recommendation because `api/scan.js` needs a serverless runtime.
GitHub Pages serves static files only, so the scanner's price lookup would not
work there.

### Netlify

Works the same way, but move `api/scan.js` to `netlify/functions/scan.js` and
change the export to Netlify's handler signature. Build command `npm run build`,
publish directory `dist`.

---

## The clothing scanner

Tap **Identify this item** after adding a photo. It tries three things in order:

1. **Claude** — reads the garment, the brand, and the price off a visible tag,
   or searches the web for the retail price. Needs an API key (below).
2. **Hugging Face** — a free ResNet-50 endpoint that returns a category only.
   No key needed, but it is often unavailable from a browser.
3. **On-device colour detection** — always works, no network, no key. Reads the
   dominant colour off a canvas.

So the scanner degrades rather than breaking. With no key at all you still get
a category some of the time and a colour every time.

### Enabling the Claude path

1. Get a key at [console.anthropic.com](https://console.anthropic.com).
2. In Vercel: **Project Settings > Environment Variables**, add
   `ANTHROPIC_API_KEY` with your key, then redeploy.
3. Locally: create a `.env` file with `ANTHROPIC_API_KEY=sk-ant-...`
   (`.env` is gitignored — do not commit your key).

The key stays on the server. `api/scan.js` forwards requests so the browser
never sees it.

**About the price:** unless it read an actual tag, that number is what the item
sells for, not what you paid. Correct it for anything secondhand, discounted,
or gifted, otherwise cost-per-wear on the Stats screen will be wrong.

---

## Where the data lives

| What | Where | Why |
|---|---|---|
| Items, outfit log, theme | `localStorage` | Small and synchronous |
| Photos | IndexedDB | localStorage caps near 5 MB; photos need more |

Photos are compressed to 640 px JPEG at 72% quality before saving, roughly
40–70 KB each.

Clearing site data in the browser wipes the closet. There is no backup — if you
want one, that means adding a real backend, and Firebase is the usual next step.

---

## Adding it to a phone home screen

Open the deployed URL in Safari or Chrome on your phone, then **Share > Add to
Home Screen**. It launches without browser chrome and behaves like an app.

This is not an App Store app. Getting into the store means rebuilding in Flutter
or React Native — the web code cannot be submitted directly.

---

## Project layout

```
api/scan.js       Serverless proxy that hides the Anthropic API key
src/Worn.jsx      The entire app — screens, storage, scanner, theming
src/main.jsx      React entry point
src/index.css     Tailwind directives and a few global rules
index.html        Document shell, fonts, PWA meta tags
```

The app is one file on purpose. It is long, but everything is in one place and
the sections are signposted with banner comments.

---

## Things you might want next

- **Sync across devices** — needs a backend. Firebase Auth plus Firestore is the
  shortest path.
- **Sharing closets with friends** — same requirement, plus privacy rules
  enforced server-side. Client-side privacy is not privacy.
- **Subscriptions** — Stripe. Free to set up; they take roughly 2.9% + $0.30 per
  transaction. Needs a backend to verify payments before unlocking anything.
- **Export** — a JSON dump of `localStorage` plus the IndexedDB photos would let
  people move their closet between browsers.
