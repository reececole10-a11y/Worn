/*
  Serverless proxy for the clothing scanner.

  The browser cannot call Anthropic directly — the API key would be visible in
  devtools to anyone who opened the page. This function holds the key server
  side and forwards the request.

  Deploys automatically on Vercel (any file in /api becomes an endpoint).
  On Netlify, move this to netlify/functions/scan.js and adjust the handler
  signature, or add the Vercel adapter.

  Required environment variable:
    ANTHROPIC_API_KEY

  Set it in Vercel under Project Settings > Environment Variables.
  Without it the endpoint returns 501 and the app falls back to Hugging Face
  plus on-device colour detection, which still work fine.
*/

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(501).json({ error: "ANTHROPIC_API_KEY is not configured" });
  }

  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(req.body),
    });

    const data = await upstream.json();
    return res.status(upstream.status).json(data);
  } catch (err) {
    console.error("Scan proxy failed:", err);
    return res.status(502).json({ error: "Upstream request failed" });
  }
}
